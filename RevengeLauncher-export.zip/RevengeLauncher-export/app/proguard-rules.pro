# /data/user/0/com.codex.mobile/files/home/codex/RevengeLauncher/app/proguard-rules.pro
# Keep serialization metadata
-keep class kotlinx.serialization.** { *; }
-keepclassmembers class ** {
    @kotlinx.serialization.SerialName *;
}
