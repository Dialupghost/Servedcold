package com.revenge.launcher.ui

import android.app.Application
import android.app.WallpaperManager
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.revenge.launcher.data.ColorTheme
import com.revenge.launcher.data.DragState
import com.revenge.launcher.data.FolderChild
import com.revenge.launcher.data.FontConfig
import com.revenge.launcher.data.InstalledApp
import com.revenge.launcher.data.LayoutMode
import com.revenge.launcher.data.LauncherPreferences
import com.revenge.launcher.data.LauncherRepository
import com.revenge.launcher.data.LauncherUiState
import com.revenge.launcher.data.PinnedItem
import com.revenge.launcher.data.PinnedItemType
import com.revenge.launcher.data.SettingsTab
import com.revenge.launcher.data.TextRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LauncherRepository(application.applicationContext)
    private val _state = MutableStateFlow(LauncherUiState())
    val state: StateFlow<LauncherUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.preferences.collect { preferences ->
                _state.update { current ->
                    current.copy(
                        preferences = preferences,
                        installedApps = if (current.installedApps.isEmpty()) repository.loadInstalledApps() else current.installedApps
                    )
                }
            }
        }
        refreshInstalledApps()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = repository.loadInstalledApps()
            _state.update { it.copy(installedApps = apps) }
        }
    }

    fun setLayoutMode(mode: LayoutMode) = updatePreferences { copy(layoutMode = mode) }

    fun toggleDrawer(visible: Boolean = !_state.value.drawerVisible) {
        _state.update { it.copy(drawerVisible = visible) }
    }

    fun setDrawerQuery(query: String) {
        _state.update { it.copy(drawerQuery = query) }
    }

    fun toggleSettings() {
        _state.update { it.copy(settingsVisible = !it.settingsVisible) }
    }

    fun setSettingsTab(tab: SettingsTab) = updatePreferences { copy(selectedTab = tab) }

    fun toggleEditMode(force: Boolean? = null) {
        _state.update { it.copy(editMode = force ?: !it.editMode) }
    }

    fun pinApp(app: InstalledApp) {
        if (_state.value.preferences.pinnedItems.any {
                it.packageName == app.packageName && it.activityName == app.activityName
            }) return
        updatePreferences {
            copy(
                pinnedItems = pinnedItems + PinnedItem(
                    label = app.label,
                    packageName = app.packageName,
                    activityName = app.activityName
                )
            )
        }
    }

    fun removePinned(itemId: String) {
        updatePreferences { copy(pinnedItems = pinnedItems.filterNot { it.id == itemId }) }
    }

    fun reorderPinned(from: Int, to: Int) {
        if (from == to || from !in _state.value.preferences.pinnedItems.indices || to !in _state.value.preferences.pinnedItems.indices) return
        updatePreferences {
            val mutable = pinnedItems.toMutableList()
            val moved = mutable.removeAt(from)
            mutable.add(to, moved)
            copy(pinnedItems = mutable)
        }
    }

    fun mergeIntoFolder(sourceId: String, targetId: String) {
        if (sourceId == targetId) return
        updatePreferences {
            val source = pinnedItems.firstOrNull { it.id == sourceId } ?: return@updatePreferences this
            val target = pinnedItems.firstOrNull { it.id == targetId } ?: return@updatePreferences this
            if (source.type == PinnedItemType.FOLDER || target.type == PinnedItemType.FOLDER) {
                val updated = pinnedItems.map {
                    when (it.id) {
                        target.id -> {
                            val newChildren = it.children + source.asFolderChild()
                            it.copy(type = PinnedItemType.FOLDER, children = newChildren)
                        }
                        source.id -> null
                        else -> it
                    }
                }.filterNotNull()
                copy(pinnedItems = updated)
            } else {
                val folder = PinnedItem(
                    id = UUID.randomUUID().toString(),
                    type = PinnedItemType.FOLDER,
                    label = "${target.label} // ${source.label}",
                    children = listOf(target.asFolderChild(), source.asFolderChild())
                )
                val updated = pinnedItems.filterNot { it.id == source.id || it.id == target.id } + folder
                copy(pinnedItems = updated)
            }
        }
    }

    fun renameFolder(folderId: String, label: String) {
        updatePreferences { copy(pinnedItems = pinnedItems.map { if (it.id == folderId) it.copy(label = label) else it }) }
    }

    fun openFolder(folderId: String?) {
        _state.update { it.copy(activeFolderId = folderId) }
    }

    fun reorderFolderChild(folderId: String, childId: String, direction: Int) {
        updatePreferences {
            copy(
                pinnedItems = pinnedItems.map { item ->
                    if (item.id != folderId) return@map item
                    val index = item.children.indexOfFirst { it.id == childId }
                    if (index == -1) return@map item
                    val targetIndex = (index + direction).coerceIn(0, item.children.lastIndex)
                    val children = item.children.toMutableList()
                    val moved = children.removeAt(index)
                    children.add(targetIndex, moved)
                    item.copy(children = children)
                }
            )
        }
    }

    fun launchPinned(item: PinnedItem) = repository.launch(item)

    fun launchFolderChild(child: FolderChild) = repository.launch(child)

    fun launchApp(app: InstalledApp) {
        repository.launch(
            PinnedItem(
                label = app.label,
                packageName = app.packageName,
                activityName = app.activityName
            )
        )
    }

    fun updateClockVisibility(showSeconds: Boolean) = updatePreferences {
        copy(wallpaper = wallpaper.copy(showSeconds = showSeconds))
    }

    fun updateDateVisibility(showDate: Boolean) = updatePreferences {
        copy(wallpaper = wallpaper.copy(showDate = showDate))
    }

    fun updateWallpaperTint(value: Long) = updatePreferences {
        copy(wallpaper = wallpaper.copy(tintArgb = value))
    }

    fun updateWallpaperOpacity(value: Float) = updatePreferences {
        copy(wallpaper = wallpaper.copy(opacity = value))
    }

    fun updateAnimation(
        damping: Float = _state.value.preferences.animation.springDamping,
        stiffness: Float = _state.value.preferences.animation.springStiffness,
        orbitSpeed: Float = _state.value.preferences.animation.orbitSpeed,
        rippleStrength: Float = _state.value.preferences.animation.rippleStrength
    ) = updatePreferences {
        copy(
            animation = animation.copy(
                springDamping = damping,
                springStiffness = stiffness,
                orbitSpeed = orbitSpeed,
                rippleStrength = rippleStrength
            )
        )
    }

    fun updateGestureSwipeDrawer(enabled: Boolean) = updatePreferences {
        copy(gestures = gestures.copy(swipeUpOpensDrawer = enabled))
    }

    fun updateGestureLongPressEdit(enabled: Boolean) = updatePreferences {
        copy(gestures = gestures.copy(longPressEditMode = enabled))
    }

    fun saveTheme(theme: ColorTheme) = updatePreferences {
        val normalized = repository.normalizedTheme(theme)
        copy(
            themes = themes.filterNot { it.id == normalized.id } + normalized,
            activeThemeId = normalized.id
        )
    }

    fun setActiveTheme(themeId: String) = updatePreferences { copy(activeThemeId = themeId) }

    fun toggleSingleAccent(enabled: Boolean) = updatePreferences { copy(singleAccentMode = enabled) }

    fun replaceFont(role: TextRole, uri: Uri) {
        val config = repository.saveFontFromUri(uri, role) ?: return
        updatePreferences {
            copy(fonts = fonts.map { if (it.role == role) config else it })
        }
    }

    fun resetFont(role: TextRole) {
        updatePreferences {
            copy(fonts = fonts.map { if (it.role == role) FontConfig(role = role) else it })
        }
    }

    fun setWallpaperFromUri(uri: Uri): Boolean = repository.setWallpaperFromUri(uri)

    fun resetWallpaperToBlack(): Boolean = repository.resetWallpaperToBlack()

    fun openLiveWallpaperChooser() {
        val context = getApplication<Application>()
        val intent = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun beginDrag(itemId: String, index: Int) {
        _state.update { it.copy(dragState = DragState(itemId = itemId, startIndex = index, currentIndex = index, active = true)) }
    }

    fun updateDrag(dragY: Float, currentIndex: Int) {
        _state.update { it.copy(dragState = it.dragState.copy(dragY = dragY, currentIndex = currentIndex)) }
    }

    fun endDrag(mergeTargetId: String? = null, trash: Boolean = false) {
        val drag = _state.value.dragState
        if (!drag.active) return
        when {
            trash -> removePinned(drag.itemId)
            mergeTargetId != null -> mergeIntoFolder(drag.itemId, mergeTargetId)
            drag.startIndex != drag.currentIndex && drag.currentIndex >= 0 -> reorderPinned(drag.startIndex, drag.currentIndex)
        }
        _state.update { it.copy(dragState = DragState()) }
    }

    private fun updatePreferences(transform: LauncherPreferences.() -> LauncherPreferences) {
        val updated = _state.value.preferences.transform()
        _state.update { it.copy(preferences = updated) }
        viewModelScope.launch { repository.savePreferences(updated) }
    }

    private fun PinnedItem.asFolderChild(): FolderChild = FolderChild(
        label = label,
        packageName = packageName.orEmpty(),
        activityName = activityName.orEmpty()
    )
}
