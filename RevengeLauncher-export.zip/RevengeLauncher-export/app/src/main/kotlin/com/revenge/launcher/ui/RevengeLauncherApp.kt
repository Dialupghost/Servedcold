package com.revenge.launcher.ui

import android.app.WallpaperManager
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.GetContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberScrollableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInParent
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.revenge.launcher.data.ColorTheme
import com.revenge.launcher.data.FontConfig
import com.revenge.launcher.data.InstalledApp
import com.revenge.launcher.data.LayoutMode
import com.revenge.launcher.data.PinnedItem
import com.revenge.launcher.data.PinnedItemType
import com.revenge.launcher.data.SettingsTab
import com.revenge.launcher.data.TextRole
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun RevengeLauncherApp(viewModel: LauncherViewModel) {
    val state by viewModel.state.collectAsState()
    val theme = state.preferences.activeTheme()
    val fonts = state.preferences.fonts.associateBy { it.role }
    val context = LocalContext.current
    val wallpaperManager = remember { WallpaperManager.getInstance(context) }
    val fontPickerRole = remember { mutableStateOf<TextRole?>(null) }

    val wallpaperPicker = rememberLauncherForActivityResult(GetContent()) { uri: Uri? ->
        uri?.let { viewModel.setWallpaperFromUri(it) }
    }
    val fontPicker = rememberLauncherForActivityResult(GetContent()) { uri: Uri? ->
        val role = fontPickerRole.value ?: return@rememberLauncherForActivityResult
        uri?.let { viewModel.replaceFont(role, it) }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = theme.background()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(theme.background())
                .pointerInput(state.preferences.gestures.longPressEditMode) {
                    detectTapGestures(
                        onLongPress = {
                            if (state.preferences.gestures.longPressEditMode) viewModel.toggleEditMode()
                        }
                    )
                }
        ) {
            WallpaperLayer(
                wallpaperDrawable = runCatching { wallpaperManager.drawable }.getOrNull(),
                theme = theme,
                opacity = state.preferences.wallpaper.opacity
            )
            LauncherScaffold(
                state = state,
                theme = theme,
                fonts = fonts,
                onLaunch = viewModel::launchPinned,
                onFolderOpen = viewModel::openFolder,
                onDrawerToggle = { viewModel.toggleDrawer() },
                onSettingsToggle = viewModel::toggleSettings,
                onEditToggle = { viewModel.toggleEditMode() },
                onDragStart = viewModel::beginDrag,
                onDragUpdate = viewModel::updateDrag,
                onDragEnd = viewModel::endDrag
            )
            if (state.drawerVisible) {
                DrawerSheet(
                    state = state,
                    theme = theme,
                    font = fonts[TextRole.DRAWER] ?: FontConfig(TextRole.DRAWER),
                    onClose = { viewModel.toggleDrawer(false) },
                    onQueryChange = viewModel::setDrawerQuery,
                    onPin = viewModel::pinApp,
                    onLaunch = viewModel::launchApp
                )
            }
            if (state.settingsVisible) {
                SettingsOverlay(
                    state = state,
                    theme = theme,
                    fonts = fonts,
                    onClose = viewModel::toggleSettings,
                    onLayoutMode = viewModel::setLayoutMode,
                    onSetTab = viewModel::setSettingsTab,
                    onThemeSave = viewModel::saveTheme,
                    onThemeSelect = viewModel::setActiveTheme,
                    onSingleAccent = viewModel::toggleSingleAccent,
                    onFontPick = {
                        fontPickerRole.value = it
                        fontPicker.launch("*/*")
                    },
                    onFontReset = viewModel::resetFont,
                    onSecondsToggle = viewModel::updateClockVisibility,
                    onDateToggle = viewModel::updateDateVisibility,
                    onAnimationChange = viewModel::updateAnimation,
                    onWallpaperPick = { wallpaperPicker.launch("image/*") },
                    onWallpaperReset = viewModel::resetWallpaperToBlack,
                    onLiveWallpaper = viewModel::openLiveWallpaperChooser,
                    onWallpaperTint = viewModel::updateWallpaperTint,
                    onWallpaperOpacity = viewModel::updateWallpaperOpacity,
                    onSwipeDrawer = viewModel::updateGestureSwipeDrawer,
                    onLongPressEdit = viewModel::updateGestureLongPressEdit
                )
            }
            FolderOrbitPopup(
                state = state,
                theme = theme,
                fonts = fonts,
                onDismiss = { viewModel.openFolder(null) },
                onLaunch = viewModel::launchFolderChild,
                onMove = viewModel::reorderFolderChild
            )
        }
    }
}

@Composable
private fun WallpaperLayer(
    wallpaperDrawable: Drawable?,
    theme: ColorTheme,
    opacity: Float
) {
    if (wallpaperDrawable == null) return
    AndroidView(
        modifier = Modifier.fillMaxSize().alpha(opacity.coerceIn(0f, 1f)),
        factory = { context ->
            android.view.View(context).apply { background = wallpaperDrawable }
        }
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(theme.background().copy(alpha = 0.18f))
    )
}

@Composable
private fun LauncherScaffold(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    fonts: Map<TextRole, FontConfig>,
    onLaunch: (PinnedItem) -> Unit,
    onFolderOpen: (String?) -> Unit,
    onDrawerToggle: () -> Unit,
    onSettingsToggle: () -> Unit,
    onEditToggle: () -> Unit,
    onDragStart: (String, Int) -> Unit,
    onDragUpdate: (Float, Int) -> Unit,
    onDragEnd: (String?, Boolean) -> Unit
) {
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val itemBounds = remember { mutableStateMapOf<String, Rect>() }
    val lazyState = rememberLazyListState()
    val scrollPulse = remember { Animatable(0f) }
    var mergeTargetId by remember { mutableStateOf<String?>(null) }
    var trashHotspot by remember { mutableStateOf(false) }

    LaunchedEffect(lazyState.firstVisibleItemScrollOffset, lazyState.firstVisibleItemIndex) {
        scrollPulse.snapTo(0f)
        scrollPulse.animateTo(
            1f,
            animationSpec = tween(420, easing = LinearEasing)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = topInset + 12.dp, bottom = bottomInset + 12.dp, start = 12.dp, end = 12.dp)
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    ) {
        ClockCluster(
            theme = theme,
            fonts = fonts,
            showSeconds = state.preferences.wallpaper.showSeconds,
            showDate = state.preferences.wallpaper.showDate,
            modifier = Modifier.align(Alignment.TopCenter)
        )
        GearButton(
            modifier = Modifier.align(Alignment.TopEnd),
            theme = theme,
            onClick = onSettingsToggle
        )
        EditBadge(
            visible = state.editMode,
            modifier = Modifier.align(Alignment.TopStart),
            theme = theme,
            font = fonts[TextRole.UI] ?: FontConfig(TextRole.UI),
            onClick = onEditToggle
        )
        when (state.preferences.layoutMode) {
            LayoutMode.VERTICAL_LIST -> {
                VerticalListLayout(
                    state = state,
                    theme = theme,
                    font = fonts[TextRole.PINNED] ?: FontConfig(TextRole.PINNED),
                    listState = lazyState,
                    boundsMap = itemBounds,
                    onLaunch = onLaunch,
                    onFolderOpen = onFolderOpen,
                    onDragStart = onDragStart,
                    onDragUpdate = { dragY, index ->
                        mergeTargetId = itemBounds.entries.firstOrNull {
                            it.value.contains(Offset(itemBounds[state.dragState.itemId]?.center?.x ?: 0f, dragY))
                        }?.key?.takeIf { it != state.dragState.itemId }
                        trashHotspot = dragY < 168f
                        onDragUpdate(dragY, index)
                    },
                    onDragEnd = {
                        onDragEnd(mergeTargetId, trashHotspot)
                        mergeTargetId = null
                        trashHotspot = false
                    }
                )
            }
            LayoutMode.RADIAL_ORBIT -> RadialOrbitLayout(
                state = state,
                theme = theme,
                font = fonts[TextRole.PINNED] ?: FontConfig(TextRole.PINNED),
                onLaunch = onLaunch,
                onFolderOpen = onFolderOpen
            )
            LayoutMode.GRID_SNAP -> GridSnapLayout(
                state = state,
                theme = theme,
                font = fonts[TextRole.PINNED] ?: FontConfig(TextRole.PINNED),
                onLaunch = onLaunch,
                onFolderOpen = onFolderOpen
            )
            LayoutMode.MINIMAL_CENTER -> MinimalCenterLayout(
                state = state,
                theme = theme,
                font = fonts[TextRole.PINNED] ?: FontConfig(TextRole.PINNED),
                onLaunch = onLaunch,
                onFolderOpen = onFolderOpen
            )
        }

        MotionRipples(
            modifier = Modifier.align(Alignment.Center).fillMaxSize(),
            theme = theme,
            pulse = scrollPulse.value,
            dragRect = itemBounds[state.dragState.itemId]
        )
        KnockoutOverlay(
            modifier = Modifier.fillMaxSize(),
            dragRect = itemBounds[state.dragState.itemId]?.let { rect ->
                Rect(rect.left, rect.top + state.dragState.dragY, rect.right, rect.bottom + state.dragState.dragY)
            },
            staticRects = itemBounds.filterKeys { it != state.dragState.itemId }.values.toList()
        )
        SwipeHandle(
            modifier = Modifier.align(Alignment.BottomCenter),
            theme = theme,
            enabled = state.preferences.gestures.swipeUpOpensDrawer,
            onDrawerToggle = onDrawerToggle
        )
    }
}

@Composable
private fun ClockCluster(
    theme: ColorTheme,
    fonts: Map<TextRole, FontConfig>,
    showSeconds: Boolean,
    showDate: Boolean,
    modifier: Modifier = Modifier
) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(showSeconds) {
        while (true) {
            now = System.currentTimeMillis()
            delay(if (showSeconds) 1000L else 60_000L)
        }
    }
    val pattern = if (showSeconds) "HH:mm:ss" else "HH:mm"
    val timeText = remember(now, showSeconds) {
        java.text.SimpleDateFormat(pattern, java.util.Locale.getDefault()).format(java.util.Date(now))
    }
    val dateText = remember(now) {
        java.text.SimpleDateFormat("EEE dd MMM", java.util.Locale.getDefault()).format(java.util.Date(now))
    }
    Column(
        modifier = modifier.padding(top = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GeometricFrame(theme = theme, modifier = Modifier.fillMaxWidth(0.7f).height(84.dp))
        LauncherText(
            text = timeText,
            modifier = Modifier.fillMaxWidth().height(72.dp),
            color = theme.primary(),
            size = 36.sp,
            fontConfig = fonts[TextRole.CLOCK] ?: FontConfig(TextRole.CLOCK),
            letterSpacing = 0.06f,
            weight = FontWeight.Bold
        )
        AnimatedVisibility(showDate) {
            LauncherText(
                text = dateText,
                modifier = Modifier.fillMaxWidth().height(26.dp),
                color = theme.secondary(),
                size = 12.sp,
                fontConfig = fonts[TextRole.UI] ?: FontConfig(TextRole.UI),
                letterSpacing = 0.18f,
                alpha = 0.86f
            )
        }
    }
}

@Composable
private fun GeometricFrame(theme: ColorTheme, modifier: Modifier = Modifier) {
    val orbit = rememberInfiniteTransition(label = "clock_orbit")
    val phase by orbit.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(7200, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "phase"
    )
    Canvas(modifier = modifier) {
        val slabHeight = size.height * 0.18f
        drawRoundRect(color = theme.line(), topLeft = Offset(size.width * 0.05f, slabHeight), size = Size(size.width * 0.9f, slabHeight), cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f))
        drawRoundRect(color = theme.line(), topLeft = Offset(size.width * 0.32f, size.height * 0.08f), size = Size(size.width * 0.08f, size.height * 0.78f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f))
        drawCircle(color = theme.primary(), radius = size.height * 0.32f, center = Offset(size.width * 0.82f, size.height * 0.5f), style = Stroke(width = 4.dp.toPx()))
        drawCircle(color = theme.dot(), radius = 4.dp.toPx(), center = Offset(size.width * (0.82f + 0.11f * cos(phase * 2f * PI).toFloat()), size.height * (0.5f + 0.22f * sin(phase * 2f * PI).toFloat())))
        val triangle = Path().apply {
            moveTo(size.width * 0.05f, size.height * 0.72f)
            lineTo(size.width * 0.12f, size.height * 0.58f)
            lineTo(size.width * 0.12f, size.height * 0.86f)
            close()
        }
        drawPath(triangle, theme.accent())
        repeat(7) {
            drawCircle(theme.dot(), radius = 1.4.dp.toPx(), center = Offset(size.width * (0.18f + it * 0.06f), size.height * 0.86f))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VerticalListLayout(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    font: FontConfig,
    listState: androidx.compose.foundation.lazy.LazyListState,
    boundsMap: MutableMap<String, Rect>,
    onLaunch: (PinnedItem) -> Unit,
    onFolderOpen: (String?) -> Unit,
    onDragStart: (String, Int) -> Unit,
    onDragUpdate: (Float, Int) -> Unit,
    onDragEnd: () -> Unit
) {
    var activeDragOffset by remember { mutableFloatStateOf(0f) }
    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 164.dp, bottom = 56.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        itemsIndexed(state.preferences.pinnedItems, key = { _, item -> item.id }) { index, item ->
            val animatedY by animateFloatAsState(
                targetValue = if (state.dragState.itemId == item.id) activeDragOffset else 0f,
                animationSpec = spring(dampingRatio = state.preferences.animation.springDamping, stiffness = state.preferences.animation.springStiffness),
                label = "drag_offset"
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(88.dp)
                    .offset { IntOffset(0, animatedY.roundToInt()) }
                    .onGloballyPositioned { boundsMap[item.id] = it.boundsInParent() }
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {
                            if (item.type == PinnedItemType.FOLDER) onFolderOpen(item.id) else onLaunch(item)
                        },
                        onLongClick = {
                            if (state.editMode) onDragStart(item.id, index)
                            else if (item.type == PinnedItemType.FOLDER) onFolderOpen(item.id)
                        }
                    )
                    .pointerInput(state.editMode, state.dragState.itemId) {
                        if (!state.editMode) return@pointerInput
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                activeDragOffset = 0f
                                onDragStart(item.id, index)
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                if (state.dragState.itemId != item.id) return@detectDragGesturesAfterLongPress
                                activeDragOffset += dragAmount.y
                                val approximateIndex = (index + (activeDragOffset / 102f)).roundToInt()
                                    .coerceIn(0, state.preferences.pinnedItems.lastIndex)
                                onDragUpdate(change.position.y + activeDragOffset, approximateIndex)
                            },
                            onDragEnd = {
                                activeDragOffset = 0f
                                onDragEnd()
                            },
                            onDragCancel = {
                                activeDragOffset = 0f
                                onDragEnd()
                            }
                        )
                    }
            ) {
                PinnedItemCard(
                    item = item,
                    theme = theme,
                    font = font,
                    modifier = Modifier.fillMaxSize(),
                    highlight = state.dragState.itemId == item.id
                )
            }
        }
    }
}

@Composable
private fun PinnedItemCard(
    item: PinnedItem,
    theme: ColorTheme,
    font: FontConfig,
    modifier: Modifier = Modifier,
    highlight: Boolean
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, theme.line(), RoundedCornerShape(18.dp))
            .background(theme.background().copy(alpha = 0.78f))
            .drawWithContent {
                drawRoundRect(
                    color = if (highlight) theme.accent().copy(alpha = 0.18f) else theme.primary().copy(alpha = 0.06f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(18.dp.toPx(), 18.dp.toPx())
                )
                drawRect(
                    color = theme.line(),
                    topLeft = Offset(20.dp.toPx(), 24.dp.toPx()),
                    size = Size(size.width * 0.56f, 10.dp.toPx())
                )
                drawRect(
                    color = theme.line(),
                    topLeft = Offset(20.dp.toPx(), 42.dp.toPx()),
                    size = Size(10.dp.toPx(), size.height - 58.dp.toPx())
                )
                val triangle = Path().apply {
                    moveTo(size.width - 36.dp.toPx(), 18.dp.toPx())
                    lineTo(size.width - 22.dp.toPx(), 28.dp.toPx())
                    lineTo(size.width - 36.dp.toPx(), 38.dp.toPx())
                    close()
                }
                drawPath(triangle, theme.accent())
                drawCircle(theme.primary(), radius = 14.dp.toPx(), center = Offset(size.width - 38.dp.toPx(), size.height / 2), style = Stroke(width = 3.dp.toPx()))
                repeat(5) {
                    drawCircle(theme.dot(), radius = 1.5.dp.toPx(), center = Offset(32.dp.toPx() + it * 10.dp.toPx(), size.height - 18.dp.toPx()))
                }
                drawContent()
            }
            .padding(horizontal = 22.dp, vertical = 16.dp)
    ) {
        LauncherText(
            text = if (item.type == PinnedItemType.FOLDER) "${item.label} [${item.children.size}]" else item.label,
            modifier = Modifier.fillMaxSize(),
            color = theme.primary(),
            size = 19.sp,
            fontConfig = font,
            letterSpacing = 0.04f,
            weight = FontWeight.Medium
        )
    }
}

@Composable
private fun RadialOrbitLayout(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    font: FontConfig,
    onLaunch: (PinnedItem) -> Unit,
    onFolderOpen: (String?) -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 176.dp, bottom = 64.dp)
    ) {
        val maxW = constraints.maxWidth.toFloat()
        val maxH = constraints.maxHeight.toFloat()
        val transition = rememberInfiniteTransition(label = "orbit")
        val phase by transition.animateFloat(
            initialValue = 0f,
            targetValue = (2f * PI).toFloat(),
            animationSpec = infiniteRepeatable(animation = tween((9000 / state.preferences.animation.orbitSpeed).roundToInt().coerceAtLeast(2000), easing = LinearEasing)),
            label = "orbit_phase"
        )
        state.preferences.pinnedItems.forEachIndexed { index, item ->
            val angle = phase + (2f * PI * index / state.preferences.pinnedItems.size.coerceAtLeast(1)).toFloat()
            val radius = maxW.coerceAtMost(maxH) * (0.23f + (index % 3) * 0.11f)
            val x = maxW / 2 + cos(angle) * radius
            val y = maxH / 2 + sin(angle) * radius * 0.72f
            Box(
                modifier = Modifier
                    .offset { IntOffset((x - 84.dp.toPx()).roundToInt(), (y - 34.dp.toPx()).roundToInt()) }
                    .size(width = 168.dp, height = 68.dp)
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {
                            if (item.type == PinnedItemType.FOLDER) onFolderOpen(item.id) else onLaunch(item)
                        }
                    )
            ) {
                PinnedItemCard(item = item, theme = theme, font = font, modifier = Modifier.fillMaxSize(), highlight = false)
            }
        }
    }
}

@Composable
private fun GridSnapLayout(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    font: FontConfig,
    onLaunch: (PinnedItem) -> Unit,
    onFolderOpen: (String?) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 180.dp, bottom = 64.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(state.preferences.pinnedItems, key = { it.id }) { item ->
            Box(
                modifier = Modifier
                    .height(108.dp)
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {
                            if (item.type == PinnedItemType.FOLDER) onFolderOpen(item.id) else onLaunch(item)
                        }
                    )
            ) {
                PinnedItemCard(item = item, theme = theme, font = font, modifier = Modifier.fillMaxSize(), highlight = false)
            }
        }
    }
}

@Composable
private fun MinimalCenterLayout(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    font: FontConfig,
    onLaunch: (PinnedItem) -> Unit,
    onFolderOpen: (String?) -> Unit
) {
    val listState = rememberLazyListState()
    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 220.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        itemsIndexed(state.preferences.pinnedItems, key = { _, item -> item.id }) { _, item ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .height(96.dp)
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {
                            if (item.type == PinnedItemType.FOLDER) onFolderOpen(item.id) else onLaunch(item)
                        }
                    )
            ) {
                PinnedItemCard(item = item, theme = theme, font = font, modifier = Modifier.fillMaxSize(), highlight = false)
            }
        }
    }
}

@Composable
private fun MotionRipples(
    modifier: Modifier,
    theme: ColorTheme,
    pulse: Float,
    dragRect: Rect?
) {
    Canvas(modifier = modifier) {
        val baseY = size.height * (0.74f + 0.1f * pulse)
        for (i in 0..7) {
            val alpha = ((1f - pulse) * (1f - i / 9f)).coerceIn(0f, 1f)
            drawLine(
                color = theme.line().copy(alpha = alpha * 0.55f),
                start = Offset(size.width * 0.1f, baseY + i * 14.dp.toPx()),
                end = Offset(size.width * (0.9f - i * 0.03f), baseY + i * 14.dp.toPx()),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(
                color = theme.dot().copy(alpha = alpha),
                radius = 1.5.dp.toPx(),
                center = Offset(size.width * 0.16f + i * 16.dp.toPx(), baseY + i * 14.dp.toPx())
            )
        }
        dragRect?.let {
            drawCircle(
                color = theme.primary().copy(alpha = 0.15f),
                radius = 44.dp.toPx() + pulse * 22.dp.toPx(),
                center = it.center,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

@Composable
private fun KnockoutOverlay(
    modifier: Modifier,
    dragRect: Rect?,
    staticRects: List<Rect>
) {
    if (dragRect == null) return
    Canvas(modifier = modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
        staticRects.forEach { rect ->
            val left = maxOf(rect.left, dragRect.left)
            val top = maxOf(rect.top, dragRect.top)
            val right = minOf(rect.right, dragRect.right)
            val bottom = minOf(rect.bottom, dragRect.bottom)
            if (right > left && bottom > top) {
                drawRoundRect(
                    color = Color.Transparent,
                    topLeft = Offset(left, top),
                    size = Size(right - left, bottom - top),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                    blendMode = BlendMode.Clear
                )
            }
        }
    }
}

@Composable
private fun SwipeHandle(
    modifier: Modifier,
    theme: ColorTheme,
    enabled: Boolean,
    onDrawerToggle: () -> Unit
) {
    Box(
        modifier = modifier
            .padding(bottom = 8.dp)
            .width(180.dp)
            .height(46.dp)
            .clip(RoundedCornerShape(28.dp))
            .border(1.dp, theme.line(), RoundedCornerShape(28.dp))
            .background(theme.background().copy(alpha = 0.76f))
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectDragGesturesAfterLongPress(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        if (dragAmount.y < -4f) onDrawerToggle()
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 12.dp)) {
            drawLine(theme.primary(), Offset(size.width * 0.2f, size.height * 0.65f), Offset(size.width * 0.5f, size.height * 0.35f), strokeWidth = 3.dp.toPx())
            drawLine(theme.primary(), Offset(size.width * 0.8f, size.height * 0.65f), Offset(size.width * 0.5f, size.height * 0.35f), strokeWidth = 3.dp.toPx())
            repeat(6) {
                drawCircle(theme.dot(), radius = 1.5.dp.toPx(), center = Offset(size.width * 0.18f + it * 10.dp.toPx(), size.height * 0.88f))
            }
        }
    }
}

@Composable
private fun GearButton(
    modifier: Modifier = Modifier,
    theme: ColorTheme,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .size(64.dp)
            .clip(CircleShape)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(10.dp)) {
            val center = center
            repeat(8) { idx ->
                val angle = idx * (PI / 4f).toFloat()
                val start = Offset(center.x + cos(angle) * size.minDimension * 0.22f, center.y + sin(angle) * size.minDimension * 0.22f)
                val end = Offset(center.x + cos(angle) * size.minDimension * 0.42f, center.y + sin(angle) * size.minDimension * 0.42f)
                drawLine(theme.primary(), start, end, strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
            }
            drawCircle(theme.primary(), radius = size.minDimension * 0.17f, center = center, style = Stroke(width = 4.dp.toPx()))
            drawCircle(theme.dot(), radius = size.minDimension * 0.05f, center = center)
        }
    }
}

@Composable
private fun EditBadge(
    visible: Boolean,
    modifier: Modifier,
    theme: ColorTheme,
    font: FontConfig,
    onClick: () -> Unit
) {
    AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, theme.accent(), RoundedCornerShape(18.dp))
                .background(theme.background().copy(alpha = 0.82f))
                .combinedClickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            LauncherText(
                text = "EDIT // DRAG // MERGE // TRASH",
                color = theme.accent(),
                size = 11.sp,
                fontConfig = font,
                letterSpacing = 0.18f
            )
        }
    }
}

@Composable
private fun DrawerSheet(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    font: FontConfig,
    onClose: () -> Unit,
    onQueryChange: (String) -> Unit,
    onPin: (InstalledApp) -> Unit,
    onLaunch: (InstalledApp) -> Unit
) {
    val filtered = remember(state.drawerQuery, state.installedApps) {
        state.installedApps.filter {
            it.label.contains(state.drawerQuery, ignoreCase = true) ||
                it.packageName.contains(state.drawerQuery, ignoreCase = true)
        }
    }
    AnimatedVisibility(
        visible = true,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.62f))
                .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(0.82f)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(theme.background().copy(alpha = 0.96f))
                    .border(1.dp, theme.line(), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .padding(18.dp)
            ) {
                LauncherText(
                    text = "DRAWER // ALPHABETICAL // LONG PRESS TO PIN",
                    color = theme.secondary(),
                    size = 11.sp,
                    fontConfig = font,
                    letterSpacing = 0.14f,
                    modifier = Modifier.fillMaxWidth().height(20.dp)
                )
                TextField(
                    value = state.drawerQuery,
                    onValueChange = onQueryChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { androidx.compose.material3.Text("Search") }
                )
                Spacer(Modifier.height(14.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(filtered, key = { _, item -> item.packageName + item.activityName }) { _, app ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(76.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.dp, theme.line(), RoundedCornerShape(16.dp))
                                .background(theme.background().copy(alpha = 0.86f))
                                .combinedClickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = {
                                        onLaunch(app)
                                        onClose()
                                    },
                                    onLongClick = { onPin(app) }
                                )
                                .padding(horizontal = 18.dp, vertical = 14.dp)
                        ) {
                            DrawerRow(app = app, theme = theme, font = font)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DrawerRow(app: InstalledApp, theme: ColorTheme, font: FontConfig) {
    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.matchParentSize()) {
            drawRect(theme.line(), topLeft = Offset(0f, 8.dp.toPx()), size = Size(size.width * 0.48f, 8.dp.toPx()))
            drawCircle(theme.primary(), radius = 12.dp.toPx(), center = Offset(size.width - 20.dp.toPx(), size.height / 2), style = Stroke(width = 3.dp.toPx()))
            repeat(4) {
                drawCircle(theme.dot(), radius = 1.4.dp.toPx(), center = Offset(0f + it * 8.dp.toPx(), size.height - 6.dp.toPx()))
            }
        }
        Column(modifier = Modifier.fillMaxSize()) {
            LauncherText(text = app.label, color = theme.primary(), size = 18.sp, fontConfig = font, modifier = Modifier.fillMaxWidth().height(26.dp))
            LauncherText(text = app.packageName, color = theme.secondary(), size = 11.sp, fontConfig = font, modifier = Modifier.fillMaxWidth().height(18.dp), alpha = 0.86f)
        }
    }
}

@Composable
private fun FolderOrbitPopup(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    fonts: Map<TextRole, FontConfig>,
    onDismiss: () -> Unit,
    onLaunch: (com.revenge.launcher.data.FolderChild) -> Unit,
    onMove: (String, String, Int) -> Unit
) {
    val folder = state.preferences.pinnedItems.firstOrNull { it.id == state.activeFolderId } ?: return
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.42f))
            .pointerInput(folder.id) { detectTapGestures(onTap = { onDismiss() }) }
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .align(Alignment.Center)
                .size(320.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(1.dp, theme.line(), RoundedCornerShape(28.dp))
                .background(theme.background().copy(alpha = 0.96f))
        ) {
            val width = constraints.maxWidth.toFloat()
            val height = constraints.maxHeight.toFloat()
            LauncherText(
                text = folder.label,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 20.dp).height(28.dp).fillMaxWidth(0.75f),
                color = theme.primary(),
                size = 20.sp,
                fontConfig = fonts[TextRole.PINNED] ?: FontConfig(TextRole.PINNED),
                letterSpacing = 0.05f,
                weight = FontWeight.Bold
            )
            folder.children.forEachIndexed { index, child ->
                val angle = (2f * PI * index / folder.children.size.coerceAtLeast(1)).toFloat() - (PI / 2f).toFloat()
                val radius = width.coerceAtMost(height) * 0.28f
                val x = width / 2 + cos(angle) * radius
                val y = height / 2 + sin(angle) * radius
                Column(
                    modifier = Modifier
                        .offset { IntOffset((x - 62.dp.toPx()).roundToInt(), (y - 28.dp.toPx()).roundToInt()) }
                        .size(width = 124.dp, height = 86.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, theme.line(), RoundedCornerShape(16.dp))
                        .background(theme.background().copy(alpha = 0.86f))
                        .combinedClickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { onLaunch(child) }
                        )
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LauncherText(
                        text = child.label,
                        color = theme.primary(),
                        size = 14.sp,
                        fontConfig = fonts[TextRole.PINNED] ?: FontConfig(TextRole.PINNED),
                        modifier = Modifier.fillMaxWidth().height(22.dp),
                        maxLines = 2
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        OrbitMoveChip(text = "L", theme = theme) { onMove(folder.id, child.id, -1) }
                        OrbitMoveChip(text = "R", theme = theme) { onMove(folder.id, child.id, 1) }
                    }
                }
            }
            Canvas(modifier = Modifier.matchParentSize().padding(24.dp)) {
                drawCircle(theme.line(), radius = size.minDimension * 0.31f, center = center, style = Stroke(width = 2.dp.toPx()))
                drawCircle(theme.primary(), radius = size.minDimension * 0.08f, center = center, style = Stroke(width = 3.dp.toPx()))
            }
        }
    }
}

@Composable
private fun OrbitMoveChip(text: String, theme: ColorTheme, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 32.dp, height = 24.dp)
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, theme.line(), RoundedCornerShape(10.dp))
            .background(theme.background().copy(alpha = 0.78f))
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        LauncherText(text = text, color = theme.accent(), size = 11.sp, fontConfig = FontConfig(TextRole.UI))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SettingsOverlay(
    state: com.revenge.launcher.data.LauncherUiState,
    theme: ColorTheme,
    fonts: Map<TextRole, FontConfig>,
    onClose: () -> Unit,
    onLayoutMode: (LayoutMode) -> Unit,
    onSetTab: (SettingsTab) -> Unit,
    onThemeSave: (ColorTheme) -> Unit,
    onThemeSelect: (String) -> Unit,
    onSingleAccent: (Boolean) -> Unit,
    onFontPick: (TextRole) -> Unit,
    onFontReset: (TextRole) -> Unit,
    onSecondsToggle: (Boolean) -> Unit,
    onDateToggle: (Boolean) -> Unit,
    onAnimationChange: (Float, Float, Float, Float) -> Unit,
    onWallpaperPick: () -> Unit,
    onWallpaperReset: () -> Boolean,
    onLiveWallpaper: () -> Unit,
    onWallpaperTint: (Long) -> Unit,
    onWallpaperOpacity: (Float) -> Unit,
    onSwipeDrawer: (Boolean) -> Unit,
    onLongPressEdit: (Boolean) -> Unit
) {
    var editableTheme by remember(theme.id) { mutableStateOf(theme) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.48f))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(28.dp))
                .border(1.dp, theme.line(), RoundedCornerShape(28.dp))
                .background(theme.background().copy(alpha = 0.98f))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LauncherText(
                    text = "SETTINGS",
                    color = theme.primary(),
                    size = 22.sp,
                    fontConfig = fonts[TextRole.UI] ?: FontConfig(TextRole.UI),
                    modifier = Modifier.weight(1f).height(30.dp),
                    letterSpacing = 0.08f,
                    weight = FontWeight.Bold
                )
                OrbitMoveChip(text = "X", theme = theme, onClick = onClose)
            }
            Spacer(Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SettingsTab.entries.forEach { tab ->
                    ToggleChip(
                        text = tab.name.replace("_", " "),
                        selected = tab == state.preferences.selectedTab,
                        theme = theme
                    ) { onSetTab(tab) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                when (state.preferences.selectedTab) {
                    SettingsTab.COLORS -> {
                        ThemeEditor(
                            theme = theme,
                            editableTheme = editableTheme,
                            savedThemes = state.preferences.themes,
                            singleAccent = state.preferences.singleAccentMode,
                            onSingleAccent = onSingleAccent,
                            onThemeSelect = onThemeSelect,
                            onUpdate = { editableTheme = it },
                            onSave = { onThemeSave(editableTheme) }
                        )
                    }
                    SettingsTab.FONTS -> {
                        TextRole.entries.forEach { role ->
                            FontRow(
                                role = role,
                                config = fonts[role] ?: FontConfig(role),
                                theme = theme,
                                onPick = { onFontPick(role) },
                                onReset = { onFontReset(role) }
                            )
                        }
                    }
                    SettingsTab.LAYOUT -> {
                        LayoutMode.entries.forEach { mode ->
                            ToggleChip(
                                text = mode.name.replace("_", " "),
                                selected = mode == state.preferences.layoutMode,
                                theme = theme
                            ) { onLayoutMode(mode) }
                        }
                        ToggleLine("Show Seconds", state.preferences.wallpaper.showSeconds, theme) { onSecondsToggle(it) }
                        ToggleLine("Show Date", state.preferences.wallpaper.showDate, theme) { onDateToggle(it) }
                    }
                    SettingsTab.ANIMATION -> {
                        SliderBlock("Spring damping", state.preferences.animation.springDamping, 0.4f..1f, theme) {
                            onAnimationChange(it, state.preferences.animation.springStiffness, state.preferences.animation.orbitSpeed, state.preferences.animation.rippleStrength)
                        }
                        SliderBlock("Spring stiffness", state.preferences.animation.springStiffness, 180f..900f, theme) {
                            onAnimationChange(state.preferences.animation.springDamping, it, state.preferences.animation.orbitSpeed, state.preferences.animation.rippleStrength)
                        }
                        SliderBlock("Orbit speed", state.preferences.animation.orbitSpeed, 0.4f..2.4f, theme) {
                            onAnimationChange(state.preferences.animation.springDamping, state.preferences.animation.springStiffness, it, state.preferences.animation.rippleStrength)
                        }
                        SliderBlock("Ripple strength", state.preferences.animation.rippleStrength, 0.2f..1.4f, theme) {
                            onAnimationChange(state.preferences.animation.springDamping, state.preferences.animation.springStiffness, state.preferences.animation.orbitSpeed, it)
                        }
                    }
                    SettingsTab.WALLPAPER -> {
                        ToggleLine("Pick gallery wallpaper", true, theme) { if (it) onWallpaperPick() }
                        ToggleLine("Open live wallpaper chooser", false, theme) { if (it) onLiveWallpaper() }
                        ToggleLine("Reset wallpaper to black", false, theme) { if (it) onWallpaperReset() }
                        SliderBlock("Wallpaper opacity", state.preferences.wallpaper.opacity, 0f..1f, theme, onWallpaperOpacity)
                        ColorSliderGroup(
                            title = "Wallpaper tint",
                            value = state.preferences.wallpaper.tintArgb,
                            theme = theme,
                            onChange = onWallpaperTint
                        )
                    }
                    SettingsTab.GESTURES -> {
                        ToggleLine("Swipe up opens drawer", state.preferences.gestures.swipeUpOpensDrawer, theme, onSwipeDrawer)
                        ToggleLine("Long press toggles edit mode", state.preferences.gestures.longPressEditMode, theme, onLongPressEdit)
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeEditor(
    theme: ColorTheme,
    editableTheme: ColorTheme,
    savedThemes: List<ColorTheme>,
    singleAccent: Boolean,
    onSingleAccent: (Boolean) -> Unit,
    onThemeSelect: (String) -> Unit,
    onUpdate: (ColorTheme) -> Unit,
    onSave: () -> Unit
) {
    ToggleLine("Single accent mode", singleAccent, theme, onSingleAccent)
    ColorSliderGroup("Background", editableTheme.backgroundArgb, theme) { onUpdate(editableTheme.copy(backgroundArgb = it)) }
    ColorSliderGroup("Primary", editableTheme.primaryArgb, theme) { onUpdate(editableTheme.copy(primaryArgb = it)) }
    ColorSliderGroup("Secondary", editableTheme.secondaryArgb, theme) { onUpdate(editableTheme.copy(secondaryArgb = it)) }
    ColorSliderGroup("Accent", editableTheme.accentArgb, theme) { onUpdate(editableTheme.copy(accentArgb = it)) }
    ColorSliderGroup("Lines", editableTheme.lineArgb, theme) { onUpdate(editableTheme.copy(lineArgb = it)) }
    ColorSliderGroup("Dots", editableTheme.dotArgb, theme) { onUpdate(editableTheme.copy(dotArgb = it)) }
    ToggleChip(text = "SAVE THEME", selected = false, theme = theme, onClick = onSave)
    savedThemes.forEach { saved ->
        ToggleChip(text = saved.name, selected = saved.id == theme.id, theme = theme) { onThemeSelect(saved.id) }
    }
}

@Composable
private fun FontRow(
    role: TextRole,
    config: FontConfig,
    theme: ColorTheme,
    onPick: () -> Unit,
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, theme.line(), RoundedCornerShape(18.dp))
            .background(theme.background().copy(alpha = 0.78f))
            .padding(14.dp)
    ) {
        LauncherText(text = role.name, color = theme.accent(), size = 12.sp, fontConfig = FontConfig(TextRole.UI), modifier = Modifier.fillMaxWidth().height(18.dp), letterSpacing = 0.12f)
        LauncherText(text = "Preview 012345 // ${config.displayName}", color = theme.primary(), size = 22.sp, fontConfig = config, modifier = Modifier.fillMaxWidth().height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            ToggleChip(text = "PICK", selected = false, theme = theme, onClick = onPick)
            ToggleChip(text = "RESET", selected = false, theme = theme, onClick = onReset)
        }
    }
}

@Composable
private fun ToggleLine(text: String, enabled: Boolean, theme: ColorTheme, onToggle: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ToggleChip(text = if (enabled) "ON" else "OFF", selected = enabled, theme = theme) { onToggle(!enabled) }
        LauncherText(
            text = text,
            color = theme.primary(),
            size = 14.sp,
            fontConfig = FontConfig(TextRole.UI),
            modifier = Modifier.fillMaxWidth().height(20.dp)
        )
    }
}

@Composable
private fun SliderBlock(label: String, value: Float, range: ClosedFloatingPointRange<Float>, theme: ColorTheme, onChange: (Float) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, theme.line(), RoundedCornerShape(18.dp))
            .background(theme.background().copy(alpha = 0.78f))
            .padding(14.dp)
    ) {
        LauncherText(text = "$label // ${"%.2f".format(value)}", color = theme.primary(), size = 13.sp, fontConfig = FontConfig(TextRole.UI), modifier = Modifier.fillMaxWidth().height(18.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun ToggleChip(text: String, selected: Boolean, theme: ColorTheme, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, if (selected) theme.accent() else theme.line(), RoundedCornerShape(14.dp))
            .background(if (selected) theme.accent().copy(alpha = 0.12f) else theme.background().copy(alpha = 0.8f))
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        LauncherText(text = text, color = if (selected) theme.accent() else theme.primary(), size = 12.sp, fontConfig = FontConfig(TextRole.UI), letterSpacing = 0.08f)
    }
}

@Composable
private fun ColorSliderGroup(title: String, value: Long, theme: ColorTheme, onChange: (Long) -> Unit) {
    val a = ((value shr 24) and 0xFF).toFloat()
    val r = ((value shr 16) and 0xFF).toFloat()
    val g = ((value shr 8) and 0xFF).toFloat()
    val b = (value and 0xFF).toFloat()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, theme.line(), RoundedCornerShape(18.dp))
            .background(theme.background().copy(alpha = 0.78f))
            .padding(14.dp)
    ) {
        LauncherText(text = title, color = theme.primary(), size = 14.sp, fontConfig = FontConfig(TextRole.UI), modifier = Modifier.fillMaxWidth().height(18.dp))
        ColorPreview(value)
        ChannelSlider("A", a) { onChange(composeArgb(it, r, g, b)) }
        ChannelSlider("R", r) { onChange(composeArgb(a, it, g, b)) }
        ChannelSlider("G", g) { onChange(composeArgb(a, r, it, b)) }
        ChannelSlider("B", b) { onChange(composeArgb(a, r, g, it)) }
    }
}

@Composable
private fun ColorPreview(value: Long) {
    Box(
        modifier = Modifier
            .padding(vertical = 8.dp)
            .height(24.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(value.toULong()))
    )
}

@Composable
private fun ChannelSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column {
        LauncherText(text = "$label ${value.roundToInt()}", color = Color.White, size = 11.sp, fontConfig = FontConfig(TextRole.UI), modifier = Modifier.fillMaxWidth().height(16.dp))
        Slider(value = value, onValueChange = onChange, valueRange = 0f..255f)
    }
}

private fun composeArgb(a: Float, r: Float, g: Float, b: Float): Long {
    return ((a.roundToInt().coerceIn(0, 255).toLong() shl 24) or
        (r.roundToInt().coerceIn(0, 255).toLong() shl 16) or
        (g.roundToInt().coerceIn(0, 255).toLong() shl 8) or
        b.roundToInt().coerceIn(0, 255).toLong())
}

private fun ColorTheme.background() = Color(backgroundArgb.toULong())
private fun ColorTheme.primary() = Color(primaryArgb.toULong())
private fun ColorTheme.secondary() = Color(secondaryArgb.toULong())
private fun ColorTheme.accent() = Color(accentArgb.toULong())
private fun ColorTheme.line() = Color(lineArgb.toULong())
private fun ColorTheme.dot() = Color(dotArgb.toULong())
