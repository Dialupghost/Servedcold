package com.revenge.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val RevengeColorScheme = darkColorScheme()

@Composable
fun RevengeLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RevengeColorScheme,
        typography = Typography,
        content = content
    )
}
